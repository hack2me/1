/* Preemptive SJF (Shortest Remaining Time First) CPU scheduling */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAXP 20
#define MAXT 2000
int n, at[MAXP], bt[MAXP], nb[MAXP], pr[MAXP], ct[MAXP], tl[MAXT], T = 0;

void accept(int withPrio) {
    srand(time(NULL));
    printf("Enter number of processes: "); scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        printf("P%d  arrival time, first CPU burst%s: ", i + 1, withPrio ? ", priority (low no. = high prio)" : "");
        scanf("%d %d", &at[i], &bt[i]);
        if (withPrio) scanf("%d", &pr[i]);
        nb[i] = rand() % 10 + 1;                 /* next CPU burst generated randomly */
    }
    printf("\nNext CPU burst (random): ");
    for (int i = 0; i < n; i++) printf("P%d=%d ", i + 1, nb[i]);
    printf("\n");
    for (int t = 0; t < MAXT; t++) tl[t] = -1;
}
void report() {
    float sw = 0, st = 0;
    printf("\nGantt chart:\n|");
    int s = 0;
    for (int t = 1; t <= T; t++)
        if (t == T || tl[t] != tl[s]) {
            if (tl[s] < 0) printf(" Idle |"); else printf(" P%d |", tl[s] + 1);
            s = t;
        }
    printf("\n0");
    s = 0;
    for (int t = 1; t <= T; t++)
        if (t == T || tl[t] != tl[s]) { printf("    %d", t); s = t; }
    printf("\n\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        int tat = ct[i] - at[i], wt = tat - bt[i];
        st += tat; sw += wt;
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", i + 1, at[i], bt[i], ct[i], tat, wt);
    }
    printf("\nAverage Turnaround Time = %.2f\nAverage Waiting Time    = %.2f\n", st / n, sw / n);
}

int main() {
    int rem[MAXP], left, t = 0;
    accept(0);
    for (int i = 0; i < n; i++) rem[i] = bt[i];
    left = n;
    while (left > 0) {
        int p = -1;
        for (int i = 0; i < n; i++)
            if (rem[i] > 0 && at[i] <= t && (p == -1 || rem[i] < rem[p])) p = i;   /* least remaining time */
        tl[t] = p;                                      /* -1 = idle */
        if (p != -1 && --rem[p] == 0) { ct[p] = t + 1; left--; }
        t++;
    }
    T = t;
    report();
    return 0;
}
