/* Disk scheduling - SCAN (elevator): head goes to the disk end, then reverses */
#include <stdio.h>
#include <stdlib.h>
int main() {
    int blocks, n, head, dir, req[50], total = 0, pos;
    printf("Enter total number of disk blocks: "); scanf("%d", &blocks);
    printf("Enter number of requests: "); scanf("%d", &n);
    printf("Enter request string: ");
    for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Enter current head position: "); scanf("%d", &head);
    printf("Enter direction (0 = Left, 1 = Right): "); scanf("%d", &dir);

    for (int i = 0; i < n - 1; i++)           /* sort ascending */
        for (int j = 0; j < n - i - 1; j++)
            if (req[j] > req[j + 1]) { int t = req[j]; req[j] = req[j + 1]; req[j + 1] = t; }
    int k = 0;
    while (k < n && req[k] < head) k++;       /* req[0..k-1] < head <= req[k..] */

    pos = head;
    printf("\nOrder of service: %d", head);
    if (dir == 0) {                            /* LEFT first */
        for (int i = k - 1; i >= 0; i--) { total += pos - req[i]; pos = req[i]; printf(" -> %d", pos); }
        if (k < n) {                           /* requests remain on right: touch end 0 and reverse */
            total += pos - 0; pos = 0; printf(" -> %d", pos);
            for (int i = k; i < n; i++) { total += req[i] - pos; pos = req[i]; printf(" -> %d", pos); }
        }
    } else {                                   /* RIGHT first */
        for (int i = k; i < n; i++) { total += req[i] - pos; pos = req[i]; printf(" -> %d", pos); }
        if (k > 0) {
            total += (blocks - 1) - pos; pos = blocks - 1; printf(" -> %d", pos);
            for (int i = k - 1; i >= 0; i--) { total += pos - req[i]; pos = req[i]; printf(" -> %d", pos); }
        }
    }
    printf("\nTotal number of head movements = %d\n", total);
    return 0;
}
