/* Disk scheduling - C-SCAN: go to one end, jump to the other end, continue same direction */
#include <stdio.h>
#include <stdlib.h>
int main() {
    int blocks, n, head, dir, req[50], total = 0, pos;
    printf("Enter total number of disk blocks (disk size): "); scanf("%d", &blocks);
    printf("Enter number of requests: "); scanf("%d", &n);
    printf("Enter request string: ");
    for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Enter current head position: "); scanf("%d", &head);
    printf("Enter direction (0 = Left, 1 = Right): "); scanf("%d", &dir);
    int last = blocks - 1;

    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (req[j] > req[j + 1]) { int t = req[j]; req[j] = req[j + 1]; req[j + 1] = t; }
    int k = 0;
    while (k < n && req[k] < head) k++;

    pos = head;
    printf("\nOrder of service: %d", head);
    if (dir == 1) {
        for (int i = k; i < n; i++) { total += req[i] - pos; pos = req[i]; printf(" -> %d", pos); }
        if (k > 0) {
            total += last - pos; pos = last; printf(" -> %d", pos);       /* go to last block */
            total += last; pos = 0; printf(" -> %d", pos);                /* jump to block 0 */
            for (int i = 0; i < k; i++) { total += req[i] - pos; pos = req[i]; printf(" -> %d", pos); }
        }
    } else {
        for (int i = k - 1; i >= 0; i--) { total += pos - req[i]; pos = req[i]; printf(" -> %d", pos); }
        if (k < n) {
            total += pos; pos = 0; printf(" -> %d", pos);                 /* go to block 0 */
            total += last; pos = last; printf(" -> %d", pos);             /* jump to last block */
            for (int i = n - 1; i >= k; i--) { total += pos - req[i]; pos = req[i]; printf(" -> %d", pos); }
        }
    }
    printf("\nTotal number of head movements = %d (return jump counted)\n", total);
    return 0;
}
