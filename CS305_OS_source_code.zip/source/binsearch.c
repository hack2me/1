/* Child program loaded by execve: usage ./binsearch key sorted_elements... */
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {
    if (argc < 3) { printf("Usage: %s key sorted_array...\n", argv[0]); return 1; }
    int key = atoi(argv[1]), n = argc - 2, a[50];
    for (int i = 0; i < n; i++) a[i] = atoi(argv[i + 2]);
    int lo = 0, hi = n - 1, found = -1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (a[mid] == key) { found = mid; break; }
        else if (a[mid] < key) lo = mid + 1;
        else hi = mid - 1;
    }
    if (found >= 0) printf("Binary search: %d found at position %d (index %d)\n", key, found + 1, found);
    else printf("Binary search: %d not found\n", key);
    return 0;
}
