/* Linked file allocation simulation */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define MAXB 200
#define MAXF 20
int n, bv[MAXB];                       /* bit vector: 1 = allocated, 0 = free */

void init() {
    srand(time(NULL));
    printf("Enter number of disk blocks: "); scanf("%d", &n);
    for (int i = 0; i < n; i++) bv[i] = (rand() % 100) < 25;     /* ~25% blocks randomly allocated */
}
void showBV() {
    printf("\nBit vector (1 = allocated, 0 = free):\n");
    for (int i = 0; i < n; i++) printf("%d", bv[i]);
    printf("\nFree blocks: ");
    for (int i = 0; i < n; i++) if (!bv[i]) printf("%d ", i);
    printf("\n");
}

struct File { char name[20]; int start, len, used; int blk[MAXB]; } dir[MAXF];
int nf = 0, nextp[MAXB];                          /* nextp[b] = pointer stored in block b (-1 = end) */

void create() {
    char nm[20]; int len, freec = 0;
    printf("Enter file name and number of blocks: "); scanf("%s %d", nm, &len);
    for (int i = 0; i < n; i++) if (!bv[i]) freec++;
    if (len > freec) { printf("Not enough free blocks (free = %d)\n", freec); return; }
    int got = 0, prev = -1;
    strcpy(dir[nf].name, nm); dir[nf].len = len; dir[nf].used = 1;
    while (got < len) {                               /* any free block can be used (scattered) */
        int b = rand() % n;
        if (bv[b]) continue;
        bv[b] = 1; dir[nf].blk[got++] = b; nextp[b] = -1;
        if (prev == -1) dir[nf].start = b; else nextp[prev] = b;
        prev = b;
    }
    nf++;
    printf("File '%s' created. Start block = %d\n", nm, dir[nf - 1].start);
}
void show() {
    printf("\nFile\tStart\tLength\tChain\n");
    for (int i = 0; i < nf; i++) if (dir[i].used) {
        printf("%s\t%d\t%d\t", dir[i].name, dir[i].start, dir[i].len);
        for (int b = dir[i].start; b != -1; b = nextp[b]) printf("%d -> ", b);
        printf("NULL\n");
    }
}
void del() {
    char nm[20];
    printf("Enter file name to delete: "); scanf("%s", nm);
    for (int i = 0; i < nf; i++)
        if (dir[i].used && !strcmp(dir[i].name, nm)) {
            for (int k = 0; k < dir[i].len; k++) bv[dir[i].blk[k]] = 0;
            dir[i].used = 0; printf("File '%s' deleted\n", nm); return;
        }
    printf("File not found\n");
}
int main() {
    int ch;
    init();
    do {
        printf("\n1. Show Bit Vector\n2. Create New File\n3. Show Directory\n4. Delete File\n5. Exit\nChoice: ");
        scanf("%d", &ch);
        switch (ch) { case 1: showBV(); break; case 2: create(); break; case 3: show(); break; case 4: del(); break; }
    } while (ch != 5);
    return 0;
}
