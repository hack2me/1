/* Round Robin CPU scheduling */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAXP 20
#define MAXT 2000
int n, at[MAXP], bt[MAXP], nb[MAXP], pr[MAXP], ct[MAXP], tl[MAXT], T = 0;

void accept(int withPrio) {
    srand(time(NULL));
    printf("Enter number of processes: "); scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        printf("P%d  arrival time, first CPU burst%s: ", i + 1, withPrio ? ", priority (low no. = high prio)" : "");
        scanf("%d %d", &at[i], &bt[i]);
        if (withPrio) scanf("%d", &pr[i]);
        nb[i] = rand() % 10 + 1;                 /* next CPU burst generated randomly */
    }
    printf("\nNext CPU burst (random): ");
    for (int i = 0; i < n; i++) printf("P%d=%d ", i + 1, nb[i]);
    printf("\n");
    for (int t = 0; t < MAXT; t++) tl[t] = -1;
}
void report() {
    float sw = 0, st = 0;
    printf("\nGantt chart:\n|");
    int s = 0;
    for (int t = 1; t <= T; t++)
        if (t == T || tl[t] != tl[s]) {
            if (tl[s] < 0) printf(" Idle |"); else printf(" P%d |", tl[s] + 1);
            s = t;
        }
    printf("\n0");
    s = 0;
    for (int t = 1; t <= T; t++)
        if (t == T || tl[t] != tl[s]) { printf("    %d", t); s = t; }
    printf("\n\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        int tat = ct[i] - at[i], wt = tat - bt[i];
        st += tat; sw += wt;
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", i + 1, at[i], bt[i], ct[i], tat, wt);
    }
    printf("\nAverage Turnaround Time = %.2f\nAverage Waiting Time    = %.2f\n", st / n, sw / n);
}

int main() {
    int rem[MAXP], q, queue[MAXT], f = 0, r = 0, inq[MAXP] = {0}, t = 0, left;
    accept(0);
    printf("Enter time quantum: "); scanf("%d", &q);
    for (int i = 0; i < n; i++) rem[i] = bt[i];
    left = n;
    while (left > 0) {
        for (int i = 0; i < n; i++)                    /* admit newly arrived processes */
            if (!inq[i] && at[i] <= t) { queue[r++] = i; inq[i] = 1; }
        if (f == r) { tl[t++] = -1; continue; }          /* ready queue empty: CPU idle */
        int p = queue[f++];
        int run = rem[p] < q ? rem[p] : q;
        for (int k = 0; k < run; k++) {
            tl[t++] = p;
            for (int i = 0; i < n; i++)                  /* arrivals during this slice enter first */
                if (!inq[i] && at[i] <= t) { queue[r++] = i; inq[i] = 1; }
        }
        rem[p] -= run;
        if (rem[p] == 0) { ct[p] = t; left--; }
        else queue[r++] = p;                             /* preempted: back of queue */
    }
    T = t;
    report();
    return 0;
}
