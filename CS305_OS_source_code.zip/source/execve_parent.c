/* Parent sorts array, child execve()s ./binsearch passing sorted array via command-line arguments */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main() {
    int n, a[50], key;
    printf("Enter number of integers: "); scanf("%d", &n);
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++) scanf("%d", &a[i]);
    printf("Enter element to search: "); scanf("%d", &key);

    for (int i = 0; i < n - 1; i++)                    /* parent sorts the array */
        for (int j = 0; j < n - i - 1; j++)
            if (a[j] > a[j + 1]) { int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; }
    printf("Sorted array: ");
    for (int i = 0; i < n; i++) printf("%d ", a[i]);
    printf("\n");

    fflush(stdout);                                    /* avoid duplicated buffered output */
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); exit(1); }
    if (pid == 0) {
        char *args[60];
        char buf[60][12];
        args[0] = "./binsearch";
        sprintf(buf[0], "%d", key);  args[1] = buf[0];        /* argv[1] = key */
        for (int i = 0; i < n; i++) { sprintf(buf[i + 1], "%d", a[i]); args[i + 2] = buf[i + 1]; }
        args[n + 2] = NULL;
        execve("./binsearch", args, NULL);               /* load new program */
        perror("execve");                                 /* reached only on failure */
        exit(1);
    }
    wait(NULL);
    return 0;
}
