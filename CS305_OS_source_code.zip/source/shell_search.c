/* Simple shell: prompt '$'. Extra command: search f|a|c filename pattern */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
void search(char *opt, char *fname, char *pat) {
    FILE *fp = fopen(fname, "r");
    if (!fp) { perror(fname); return; }
    char line[512]; int ln = 0, total = 0, found = 0;
    while (fgets(line, sizeof line, fp)) {
        ln++;
        char *p = line; int here = 0;
        while ((p = strstr(p, pat)) != NULL) { here++; p += strlen(pat); }   /* occurrences in this line */
        if (!here) continue;
        total += here;
        line[strcspn(line, "\n")] = 0;
        if (!strcmp(opt, "f")) { printf("First occurrence at line %d: %s\n", ln, line); found = 1; break; }
        if (!strcmp(opt, "a")) { printf("Line %d: %s\n", ln, line); found = 1; }
    }
    fclose(fp);
    if (!strcmp(opt, "c")) printf("Pattern '%s' occurs %d time(s)\n", pat, total);
    else if (!strcmp(opt, "f") || !strcmp(opt, "a")) { if (!found) printf("Pattern '%s' not found\n", pat); }
    else printf("search: invalid option '%s' (use f, a or c)\n", opt);
}
int main() {
    char line[256], *args[20];
    while (1) {
        printf("$ "); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) break;
        int k = 0;
        for (char *t = strtok(line, " \t\n"); t && k < 19; t = strtok(NULL, " \t\n")) args[k++] = t;
        args[k] = NULL;
        if (k == 0) continue;
        if (!strcmp(args[0], "exit")) break;
        if (!strcmp(args[0], "search")) {
            if (k != 4) printf("Usage: search f|a|c filename pattern\n"); else search(args[1], args[2], args[3]);
            continue;
        }
        pid_t pid = fork();
        if (pid == 0) { execvp(args[0], args); perror(args[0]); exit(1); }
        else if (pid > 0) wait(NULL);
        else perror("fork");
    }
    return 0;
}
