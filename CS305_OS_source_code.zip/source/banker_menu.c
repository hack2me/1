/* Banker's algorithm - menu driven (Accept Available, Display Alloc/Max, Need, Available) */
#include <stdio.h>
#define MAXP 10
#define MAXR 10
int n, m, alloc[MAXP][MAXR], mx[MAXP][MAXR], need[MAXP][MAXR], avail[MAXR];

void acceptMatrix(const char *nm, int a[MAXP][MAXR]) {
    printf("Enter %s matrix (%d x %d):\n", nm, n, m);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) scanf("%d", &a[i][j]);
}
void displayAllocMax() {
    printf("\nProcess\tAllocation\tMax\n\t");
    for (int k = 0; k < 2; k++) {
        for (int j = 0; j < m; j++) printf("%c ", 'A' + j);
        printf("\t");
    }
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t", i);
        for (int j = 0; j < m; j++) printf("%d ", alloc[i][j]);
        printf("\t\t");
        for (int j = 0; j < m; j++) printf("%d ", mx[i][j]);
        printf("\n");
    }
}
void findNeed() {
    int bad = 0;
    printf("\nNeed matrix (Max - Allocation):\nProcess\t");
    for (int j = 0; j < m; j++) printf("%c ", 'A' + j);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t", i);
        for (int j = 0; j < m; j++) {
            need[i][j] = mx[i][j] - alloc[i][j];
            if (need[i][j] < 0) bad = 1;
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }
    if (bad) printf("Warning: negative Need => Max < Allocation for some process (check input data)\n");
}
void displayAvail() {
    printf("\nAvailable: ");
    for (int j = 0; j < m; j++) printf("%c=%d ", 'A' + j, avail[j]);
    printf("\n");
}
int main() {
    int ch;
    printf("Enter number of processes: "); scanf("%d", &n);
    printf("Enter number of resource types: "); scanf("%d", &m);
    acceptMatrix("Allocation", alloc);
    acceptMatrix("Max", mx);
    do {
        printf("\n---- MENU ----\n1. Accept Available\n2. Display Allocation, Max\n"
               "3. Display contents of Need matrix\n4. Display Available\n5. Exit\nChoice: ");
        scanf("%d", &ch);
        switch (ch) {
        case 1:
            printf("Enter Available (%d values): ", m);
            for (int j = 0; j < m; j++) scanf("%d", &avail[j]);
            break;
        case 2: displayAllocMax(); break;
        case 3: findNeed(); break;
        case 4: displayAvail(); break;
        case 5: break;
        default: printf("Invalid choice\n");
        }
    } while (ch != 5);
    return 0;
}
