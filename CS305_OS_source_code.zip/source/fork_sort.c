/* fork(): parent bubble-sorts and waits; child insertion-sorts */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
void show(const char *who, int *a, int n) {
    printf("%s sorted array: ", who);
    for (int i = 0; i < n; i++) printf("%d ", a[i]);
    printf("\n");
}
int main() {
    int n, a[50], b[50];
    printf("Enter number of integers: "); scanf("%d", &n);
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++) { scanf("%d", &a[i]); b[i] = a[i]; }

    fflush(stdout);                                    /* avoid duplicated buffered output */
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); exit(1); }
    if (pid == 0) {                                    /* child: insertion sort */
        for (int i = 1; i < n; i++) {
            int key = b[i], j = i - 1;
            while (j >= 0 && b[j] > key) { b[j + 1] = b[j]; j--; }
            b[j + 1] = key;
        }
        printf("\n[Child  PID %d] Insertion sort done\n", getpid());
        show("Child ", b, n);
        exit(0);
    } else {                                           /* parent: bubble sort, then wait */
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (a[j] > a[j + 1]) { int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; }
        printf("\n[Parent PID %d] Bubble sort done\n", getpid());
        show("Parent", a, n);
        wait(NULL);                                    /* wait for child to finish */
        printf("[Parent] Child finished.\n");
    }
    return 0;
}
