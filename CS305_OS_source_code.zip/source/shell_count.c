/* Simple shell: prompt '$', tokenizes, executes via fork/exec. Extra command: count c|w|l filename */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
void count(char *opt, char *fname) {
    FILE *fp = fopen(fname, "r");
    if (!fp) { perror(fname); return; }
    int c, ch = 0, w = 0, l = 0, inword = 0;
    while ((c = fgetc(fp)) != EOF) {
        ch++;
        if (c == '\n') l++;
        if (c == ' ' || c == '\n' || c == '\t') inword = 0;
        else if (!inword) { inword = 1; w++; }
    }
    fclose(fp);
    if (!strcmp(opt, "c")) printf("Number of characters = %d\n", ch);
    else if (!strcmp(opt, "w")) printf("Number of words = %d\n", w);
    else if (!strcmp(opt, "l")) printf("Number of lines = %d\n", l);
    else printf("count: invalid option '%s' (use c, w or l)\n", opt);
}
int main() {
    char line[256], *args[20];
    while (1) {
        printf("$ "); fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) break;
        int k = 0;
        for (char *t = strtok(line, " \t\n"); t && k < 19; t = strtok(NULL, " \t\n")) args[k++] = t;   /* tokenize */
        args[k] = NULL;
        if (k == 0) continue;
        if (!strcmp(args[0], "exit")) break;
        if (!strcmp(args[0], "count")) {
            if (k != 3) printf("Usage: count c|w|l filename\n"); else count(args[1], args[2]);
            continue;
        }
        pid_t pid = fork();                            /* execute other commands in a child */
        if (pid == 0) { execvp(args[0], args); perror(args[0]); exit(1); }
        else if (pid > 0) wait(NULL);
        else perror("fork");
    }
    return 0;
}
