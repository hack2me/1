/* Orphan process: parent terminates before child finishes */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main() {
    setvbuf(stdout, NULL, _IONBF, 0);                  /* unbuffered: output appears in real order */
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); exit(1); }
    if (pid == 0) {                                    /* child */
        printf("Child : PID = %d, Parent PID = %d (before parent exits)\n", getpid(), getppid());
        sleep(5);                                      /* parent dies meanwhile */
        printf("Child : I am now an ORPHAN. PID = %d, new Parent PID = %d (init/systemd adopted me)\n",
               getpid(), getppid());
    } else {                                           /* parent */
        printf("Parent: PID = %d, created child PID = %d\n", getpid(), pid);
        sleep(1);
        printf("Parent: terminating before child finishes.\n");
        exit(0);
    }
    return 0;
}
