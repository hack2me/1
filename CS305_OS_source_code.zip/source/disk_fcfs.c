/* Disk scheduling - FCFS */
#include <stdio.h>
#include <stdlib.h>
int main() {
    int blocks, n, head, req[50], total = 0;
    printf("Enter total number of disk blocks: "); scanf("%d", &blocks);
    printf("Enter number of requests: "); scanf("%d", &n);
    printf("Enter request string: ");
    for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Enter current head position: "); scanf("%d", &head);

    printf("\nOrder of service: %d", head);
    for (int i = 0; i < n; i++) {
        total += abs(req[i] - head);
        head = req[i];
        printf(" -> %d", head);
    }
    printf("\nTotal number of head movements = %d\n", total);
    return 0;
}
