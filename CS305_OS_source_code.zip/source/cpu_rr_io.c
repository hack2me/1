/* Round Robin with fixed I/O wait (2 units): CPU(first burst) -> I/O(2) -> CPU(next random burst) */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAXP 20
#define MAXT 3000
#define IOWAIT 2
int n, at[MAXP], b1[MAXP], b2[MAXP], ct[MAXP], tl[MAXT], T;

int main() {
    int rem[MAXP], phase[MAXP] = {0}, ioend[MAXP], state[MAXP] = {0}; /* state: 0 not yet, 1 ready, 2 in I/O, 3 done */
    int q, queue[MAXT], f = 0, r = 0, t = 0, left;
    srand(time(NULL));
    printf("Enter number of processes: "); scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        printf("P%d  arrival time, first CPU burst: ", i + 1);
        scanf("%d %d", &at[i], &b1[i]);
        b2[i] = rand() % 10 + 1;
        rem[i] = b1[i];
    }
    printf("Enter time quantum: "); scanf("%d", &q);
    printf("\nNext CPU burst (random): ");
    for (int i = 0; i < n; i++) printf("P%d=%d ", i + 1, b2[i]);
    printf("\n");
    for (int i = 0; i < MAXT; i++) tl[i] = -1;
    left = n;
    while (left > 0) {
        for (int i = 0; i < n; i++) {
            if (state[i] == 0 && at[i] <= t) { state[i] = 1; queue[r++] = i; }
            if (state[i] == 2 && ioend[i] <= t) { state[i] = 1; queue[r++] = i; }  /* I/O complete */
        }
        if (f == r) { tl[t++] = -1; continue; }
        int p = queue[f++];
        int run = rem[p] < q ? rem[p] : q;
        for (int k = 0; k < run; k++) {
            tl[t++] = p;
            for (int i = 0; i < n; i++) {
                if (state[i] == 0 && at[i] <= t) { state[i] = 1; queue[r++] = i; }
                if (state[i] == 2 && ioend[i] <= t) { state[i] = 1; queue[r++] = i; }
            }
        }
        rem[p] -= run;
        if (rem[p] > 0) queue[r++] = p;
        else if (phase[p] == 0) { phase[p] = 1; rem[p] = b2[p]; state[p] = 2; ioend[p] = t + IOWAIT; }
        else { state[p] = 3; ct[p] = t; left--; }
    }
    T = t;
    printf("\nGantt chart (CPU):\n|");
    int s = 0;
    for (int x = 1; x <= T; x++)
        if (x == T || tl[x] != tl[s]) { if (tl[s] < 0) printf(" Idle |"); else printf(" P%d |", tl[s] + 1); s = x; }
    printf("\n0"); s = 0;
    for (int x = 1; x <= T; x++) if (x == T || tl[x] != tl[s]) { printf("    %d", x); s = x; }
    float st = 0, sw = 0;
    printf("\n\nProcess\tAT\tBurst1\tBurst2\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        int tat = ct[i] - at[i], wt = tat - b1[i] - b2[i] - IOWAIT;   /* waiting = TAT - CPU - I/O */
        st += tat; sw += wt;
        printf("P%d\t%d\t%d\t%d\t%d\t%d\t%d\n", i + 1, at[i], b1[i], b2[i], ct[i], tat, wt);
    }
    printf("\nAverage Turnaround Time = %.2f\nAverage Waiting Time    = %.2f\n", st / n, sw / n);
    return 0;
}
