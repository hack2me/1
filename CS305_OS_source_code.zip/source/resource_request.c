/* Resource-Request algorithm (Banker's): need matrix, safety check, grant request? */
#include <stdio.h>
#define MAXP 10
#define MAXR 10
int n, m, alloc[MAXP][MAXR], mx[MAXP][MAXR], need[MAXP][MAXR], avail[MAXR];

int isSafe(int *seq) {
    int work[MAXR], fin[MAXP] = {0}, cnt = 0, found = 1;
    for (int j = 0; j < m; j++) work[j] = avail[j];
    while (cnt < n && found) {
        found = 0;
        for (int i = 0; i < n; i++) {
            if (fin[i]) continue;
            int ok = 1;
            for (int j = 0; j < m; j++) if (need[i][j] > work[j]) { ok = 0; break; }
            if (ok) {
                for (int j = 0; j < m; j++) work[j] += alloc[i][j];
                fin[i] = 1; seq[cnt++] = i; found = 1;
            }
        }
    }
    return cnt == n;
}
int main() {
    int total[MAXR], seq[MAXP], mode, req[MAXR], p;
    printf("Enter number of processes and resource types: ");
    scanf("%d %d", &n, &m);
    printf("Give 1) total instances of each resource  2) Available directly: ");
    scanf("%d", &mode);
    printf("Enter %s (%d values): ", mode == 1 ? "total instances" : "Available", m);
    for (int j = 0; j < m; j++) scanf("%d", mode == 1 ? &total[j] : &avail[j]);
    printf("Enter Allocation matrix:\n");
    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &alloc[i][j]);
    printf("Enter Max matrix:\n");
    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &mx[i][j]);

    if (mode == 1)
        for (int j = 0; j < m; j++) {
            avail[j] = total[j];
            for (int i = 0; i < n; i++) avail[j] -= alloc[i][j];
        }
    printf("\nNeed matrix:\n\t");
    for (int j = 0; j < m; j++) printf("%c ", 'A' + j);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t", i);
        for (int j = 0; j < m; j++) { need[i][j] = mx[i][j] - alloc[i][j]; printf("%d ", need[i][j]); }
        printf("\n");
    }
    printf("Available: ");
    for (int j = 0; j < m; j++) printf("%d ", avail[j]);
    printf("\n");

    if (isSafe(seq)) {
        printf("\nCurrent state is SAFE. Safe sequence: ");
        for (int i = 0; i < n; i++) printf("P%d%s", seq[i], i < n - 1 ? " -> " : "\n");
    } else printf("\nCurrent state is NOT safe.\n");

    printf("\nEnter process number making request (0-%d): ", n - 1);
    scanf("%d", &p);
    printf("Enter request (%d values): ", m);
    for (int j = 0; j < m; j++) scanf("%d", &req[j]);

    for (int j = 0; j < m; j++)
        if (req[j] > need[p][j]) { printf("\nError: P%d exceeded its maximum claim. Request DENIED.\n", p); return 0; }
    for (int j = 0; j < m; j++)
        if (req[j] > avail[j]) { printf("\nResources not available. P%d must WAIT. Request cannot be granted immediately.\n", p); return 0; }
    for (int j = 0; j < m; j++) { avail[j] -= req[j]; alloc[p][j] += req[j]; need[p][j] -= req[j]; }
    if (isSafe(seq)) {
        printf("\nRequest can be GRANTED immediately. Safe sequence: ");
        for (int i = 0; i < n; i++) printf("P%d%s", seq[i], i < n - 1 ? " -> " : "\n");
    } else printf("\nGranting leaves system UNSAFE. Request cannot be granted immediately (P%d waits).\n", p);
    return 0;
}
