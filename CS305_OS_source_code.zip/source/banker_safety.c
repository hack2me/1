/* Banker's algorithm: Need matrix + safety algorithm (safe sequence) */
#include <stdio.h>
#define MAXP 10
#define MAXR 10
int main() {
    int n, m, alloc[MAXP][MAXR], mx[MAXP][MAXR], need[MAXP][MAXR];
    int avail[MAXR], work[MAXR], fin[MAXP] = {0}, seq[MAXP], cnt = 0;
    printf("Enter number of processes and resource types: ");
    scanf("%d %d", &n, &m);
    printf("Enter Allocation matrix:\n");
    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &alloc[i][j]);
    printf("Enter Max matrix:\n");
    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) scanf("%d", &mx[i][j]);
    printf("Enter Available:\n");
    for (int j = 0; j < m; j++) scanf("%d", &avail[j]);

    printf("\nNeed matrix:\n\t");
    for (int j = 0; j < m; j++) printf("%c ", 'A' + j);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t", i);
        for (int j = 0; j < m; j++) { need[i][j] = mx[i][j] - alloc[i][j]; printf("%d ", need[i][j]); }
        printf("\n");
    }
    for (int j = 0; j < m; j++) work[j] = avail[j];
    int found = 1;
    while (cnt < n && found) {
        found = 0;
        for (int i = 0; i < n; i++) {
            if (fin[i]) continue;
            int ok = 1;
            for (int j = 0; j < m; j++) if (need[i][j] > work[j]) { ok = 0; break; }
            if (ok) {
                for (int j = 0; j < m; j++) work[j] += alloc[i][j];
                fin[i] = 1; seq[cnt++] = i; found = 1;
            }
        }
    }
    if (cnt == n) {
        printf("\nSystem is in SAFE state.\nSafe sequence: ");
        for (int i = 0; i < n; i++) printf("P%d%s", seq[i], i < n - 1 ? " -> " : "\n");
    } else printf("\nSystem is NOT in a safe state (deadlock possible).\n");
    return 0;
}
