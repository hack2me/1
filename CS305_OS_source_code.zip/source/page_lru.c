/* Demand paging - LRU page replacement (counter method) */
#include <stdio.h>
#define MAXN 50
int main() {
    int n, len, ref[MAXN], frame[10], faults = 0;
    printf("Enter number of frames: "); scanf("%d", &n);
    printf("Enter length of reference string: "); scanf("%d", &len);
    printf("Enter reference string: ");
    for (int i = 0; i < len; i++) scanf("%d", &ref[i]);
    for (int i = 0; i < n; i++) frame[i] = -1;
    int counter[10] = {0}, clock = 0;       /* counter[j] = time page in frame j was last used */
    printf("\nPage | Frames\n");
    for (int i = 0; i < len; i++) {
        int hit = -1, fault = 0;
        clock++;
        for (int j = 0; j < n; j++) if (frame[j] == ref[i]) { hit = j; break; }
        if (hit >= 0) counter[hit] = clock;
        else {
            int victim = -1;
            for (int j = 0; j < n; j++) if (frame[j] == -1) { victim = j; break; }
            if (victim == -1) {
                victim = 0;
                for (int j = 1; j < n; j++) if (counter[j] < counter[victim]) victim = j;   /* least recently used */
            }
            frame[victim] = ref[i]; counter[victim] = clock; faults++; fault = 1;
        }
        printf("%3d : ", ref[i]);
        for (int j = 0; j < n; j++) { if (frame[j] == -1) printf("  - "); else printf("%3d ", frame[j]); }
        printf("%s\n", fault ? " <- page fault" : "");
    }
    printf("\nTotal number of page faults = %d\n", faults);
    return 0;
}
