/* nice(): after fork(), give the child a higher priority (lower nice value) */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/resource.h>
int main() {
    setvbuf(stdout, NULL, _IONBF, 0);                  /* unbuffered: output appears in real order */
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); exit(1); }
    if (pid == 0) {                                    /* child */
        printf("Child : initial nice value = %d\n", getpriority(PRIO_PROCESS, 0));
        errno = 0;
        int r = nice(-5);                              /* negative => higher priority (needs root) */
        if (r == -1 && errno != 0) {
            perror("Child : nice(-5) failed (run with sudo for higher priority)");
        } else printf("Child : nice(-5) called, new nice value = %d  (higher priority)\n", r);
        for (int i = 1; i <= 3; i++) { printf("Child : working %d (PID %d)\n", i, getpid()); sleep(1); }
        exit(0);
    } else {                                           /* parent */
        printf("Parent: nice value = %d (unchanged)\n", getpriority(PRIO_PROCESS, 0));
        for (int i = 1; i <= 3; i++) { printf("Parent: working %d (PID %d)\n", i, getpid()); sleep(1); }
        wait(NULL);
        printf("Parent: child finished.\n");
    }
    return 0;
}
