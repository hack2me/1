/* Disk scheduling - SSTF */
#include <stdio.h>
#include <stdlib.h>
int main() {
    int blocks, n, head, req[50], done[50] = {0}, total = 0;
    printf("Enter total number of disk blocks: "); scanf("%d", &blocks);
    printf("Enter number of requests: "); scanf("%d", &n);
    printf("Enter request string: ");
    for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Enter current head position: "); scanf("%d", &head);

    printf("\nOrder of service: %d", head);
    for (int c = 0; c < n; c++) {
        int best = -1, bd = 1 << 30;
        for (int i = 0; i < n; i++)
            if (!done[i] && abs(req[i] - head) < bd) { bd = abs(req[i] - head); best = i; }
        done[best] = 1;
        total += bd;
        head = req[best];
        printf(" -> %d", head);
    }
    printf("\nTotal number of head movements = %d\n", total);
    return 0;
}
