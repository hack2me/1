/* Disk scheduling - LOOK: head reverses at the last request, not at the disk end */
#include <stdio.h>
#include <stdlib.h>
int main() {
    int blocks, n, head, dir, req[50], total = 0, pos;
    printf("Enter total number of disk blocks: "); scanf("%d", &blocks);
    printf("Enter number of requests: "); scanf("%d", &n);
    printf("Enter request string: ");
    for (int i = 0; i < n; i++) scanf("%d", &req[i]);
    printf("Enter current head position: "); scanf("%d", &head);
    printf("Enter direction (0 = Left, 1 = Right): "); scanf("%d", &dir);

    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (req[j] > req[j + 1]) { int t = req[j]; req[j] = req[j + 1]; req[j + 1] = t; }
    int k = 0;
    while (k < n && req[k] < head) k++;

    pos = head;
    printf("\nOrder of service: %d", head);
    if (dir == 0) {
        for (int i = k - 1; i >= 0; i--) { total += pos - req[i]; pos = req[i]; printf(" -> %d", pos); }
        for (int i = k; i < n; i++)      { total += req[i] - pos; pos = req[i]; printf(" -> %d", pos); }
    } else {
        for (int i = k; i < n; i++)      { total += req[i] - pos; pos = req[i]; printf(" -> %d", pos); }
        for (int i = k - 1; i >= 0; i--) { total += pos - req[i]; pos = req[i]; printf(" -> %d", pos); }
    }
    printf("\nTotal number of head movements = %d\n", total);
    return 0;
}
