/* Demand paging - FIFO page replacement */
#include <stdio.h>
#define MAXN 50
int main() {
    int n, len, ref[MAXN], frame[10], faults = 0;
    printf("Enter number of frames: "); scanf("%d", &n);
    printf("Enter length of reference string: "); scanf("%d", &len);
    printf("Enter reference string: ");
    for (int i = 0; i < len; i++) scanf("%d", &ref[i]);
    for (int i = 0; i < n; i++) frame[i] = -1;
    int next = 0;                          /* index of oldest page */
    printf("\nPage | Frames\n");
    for (int i = 0; i < len; i++) {
        int hit = 0, fault = 0;
        for (int j = 0; j < n; j++) if (frame[j] == ref[i]) { hit = 1; break; }
        if (!hit) { frame[next] = ref[i]; next = (next + 1) % n; faults++; fault = 1; }
        printf("%3d : ", ref[i]);
        for (int j = 0; j < n; j++) { if (frame[j] == -1) printf("  - "); else printf("%3d ", frame[j]); }
        printf("%s\n", fault ? " <- page fault" : "");
    }
    printf("\nTotal number of page faults = %d\n", faults);
    return 0;
}
